/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package idev1;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.regex.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;
import org.antlr.runtime.*;

public class IDEV1 extends JFrame {

    private JTextPane editor;
    private JTextArea consola;
    private JTextArea erroresArea;
    private JTextArea tablaGlobal;
    private JTextArea tablaLocal;
    private JFileChooser fileChooser;
    private simpleParser parser;

    private static final String[] KEYWORDS = {
        "public", "private", "protected",
        "class", "int", "double", "boolean",
        "void", "for", "do", "while", "if", "else",
        "return", "new"
    };

    public IDEV1() {
        super("BIde");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setSize(1200, 760);
        setLocationRelativeTo(null);

        // Tema oscuro estilo VSCode
        UIManager.put("control", new Color(30, 30, 30));
        UIManager.put("text", new Color(230, 230, 230));
        UIManager.put("nimbusBase", new Color(18, 30, 49));
        UIManager.put("nimbusBlueGrey", new Color(48, 48, 48));
        SwingUtilities.updateComponentTreeUI(this);

        // ----- Barra de herramientas -----
        JToolBar toolBar = new JToolBar();
        toolBar.setFloatable(false);
        toolBar.setBackground(new Color(45, 45, 45));

        JButton btnCargar = crearBoton("🗂️ Cargar");
        JButton btnCompilar = crearBoton("⚙️ Compilar");
        JButton btnTablas = crearBoton("🧾 Tablas");
        toolBar.add(btnCargar);
        toolBar.add(btnCompilar);
        toolBar.add(btnTablas);
        add(toolBar, BorderLayout.NORTH);

        // ----- Editor -----
        editor = new JTextPane();
        editor.setFont(new Font("Consolas", Font.PLAIN, 16));
        editor.setBackground(new Color(40, 44, 52));
        editor.setForeground(Color.WHITE);
        editor.setCaretColor(Color.WHITE);
        editor.setMargin(new Insets(10, 10, 10, 10));
        JScrollPane scrollEditor = new JScrollPane(editor);
        scrollEditor.setBorder(BorderFactory.createTitledBorder("Editor"));

        editor.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { highlight(); }
            public void removeUpdate(DocumentEvent e) { highlight(); }
            public void changedUpdate(DocumentEvent e) {}
        });

        // ----- Consola general -----
        consola = new JTextArea();
        consola.setEditable(false);
        consola.setFont(new Font("Consolas", Font.PLAIN, 14));
        consola.setBackground(new Color(25, 25, 25));
        consola.setForeground(new Color(173, 255, 47));
        JScrollPane scrollConsola = new JScrollPane(consola);
        scrollConsola.setBorder(BorderFactory.createTitledBorder("Consola general"));

        // ----- Ventana de errores -----
        erroresArea = new JTextArea();
        erroresArea.setEditable(false);
        erroresArea.setFont(new Font("Consolas", Font.PLAIN, 14));
        erroresArea.setBackground(new Color(25, 0, 0));
        erroresArea.setForeground(new Color(255, 99, 99));
        JScrollPane scrollErrores = new JScrollPane(erroresArea);
        scrollErrores.setBorder(BorderFactory.createTitledBorder("Errores detectados"));

        // ----- Panel de tablas -----
        tablaGlobal = new JTextArea();
        tablaLocal = new JTextArea();
        tablaGlobal.setEditable(false);
        tablaLocal.setEditable(false);
        tablaGlobal.setBackground(new Color(35, 35, 35));
        tablaLocal.setBackground(new Color(35, 35, 35));
        tablaGlobal.setForeground(new Color(135, 206, 250));
        tablaLocal.setForeground(new Color(255, 160, 122));

        JPanel panelTablas = new JPanel(new GridLayout(2, 1));
        panelTablas.add(new JScrollPane(tablaGlobal));
        panelTablas.add(new JScrollPane(tablaLocal));
        panelTablas.setPreferredSize(new Dimension(300, 0));
        panelTablas.setBorder(BorderFactory.createTitledBorder("Tablas de Símbolos"));

        // ----- Divisiones -----
        JSplitPane splitErroresConsola = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, scrollErrores, scrollConsola);
        splitErroresConsola.setDividerLocation(400);

        JSplitPane splitCenter = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, scrollEditor, panelTablas);
        splitCenter.setDividerLocation(800);

        JSplitPane splitMain = new JSplitPane(JSplitPane.VERTICAL_SPLIT, splitCenter, splitErroresConsola);
        splitMain.setDividerLocation(480);

        add(splitMain, BorderLayout.CENTER);

        fileChooser = new JFileChooser();

        btnCargar.addActionListener(e -> cargarArchivo());
        btnCompilar.addActionListener(e -> compilarCodigo());
        btnTablas.addActionListener(e -> mostrarTablas());
    }

    private JButton crearBoton(String texto) {
        JButton b = new JButton(texto);
        b.setForeground(Color.WHITE);
        b.setBackground(new Color(60, 63, 65));
        b.setFocusPainted(false);
        b.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        return b;
    }

    // ----- Funciones -----

    private void cargarArchivo() {
        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File f = fileChooser.getSelectedFile();
            try (BufferedReader br = new BufferedReader(new FileReader(f))) {
                editor.setText("");
                String line;
                while ((line = br.readLine()) != null)
                    editor.getDocument().insertString(editor.getDocument().getLength(), line + "\n", null);
                consola.append("Archivo cargado: " + f.getName() + "\n");
                highlight();
            } catch (Exception ex) {
                consola.append("Error al cargar archivo: " + ex.getMessage() + "\n");
            }
        }
    }

    private void compilarCodigo() {
        consola.setText("");
        erroresArea.setText("");
        tablaGlobal.setText("");
        tablaLocal.setText("");

        try {
            String codigo = editor.getText();
            ANTLRInputStream input = new ANTLRInputStream(new ByteArrayInputStream(codigo.getBytes()));
            simpleLexer lexer = new simpleLexer(input);
            CommonTokenStream tokens = new CommonTokenStream(lexer);
            parser = new simpleParser(tokens);
            parser.setSalida(consola);

            parser.program();

            // Filtrar y mostrar errores
            for (String line : consola.getText().split("\n")) {
                if (line.trim().toLowerCase().startsWith("error"))
                    erroresArea.append(line + "\n");
            }

            consola.append("\n--- Análisis completado ---\n");

        } catch (Exception ex) {
            consola.append("Error en compilación: " + ex.getMessage() + "\n");
            erroresArea.append("Error en compilación: " + ex.getMessage() + "\n");
        }
    }

    private void mostrarTablas() {
        if (parser != null) {
            StringBuilder global = new StringBuilder("Tabla Global (TSG)\n------------------\n");
            for (String k : parser.TSG.keySet())
                global.append(k).append(" -> ").append(parser.TSG.get(k)).append("\n");
            tablaGlobal.setText(global.toString());

            StringBuilder local = new StringBuilder("Tabla Local (TSL)\n------------------\n");
            for (String k : parser.TSL.keySet())
                local.append(k).append(" -> ").append(parser.TSL.get(k)).append("\n");
            tablaLocal.setText(local.toString());
        } else {
            consola.append("Aún no se ha compilado ningún programa.\n");
        }
    }

    // ======= Resaltado de sintaxis =======

    private void highlight() {
        SwingUtilities.invokeLater(() -> {
            StyledDocument doc = editor.getStyledDocument();
            StyleContext sc = StyleContext.getDefaultStyleContext();

            Style defaultStyle = sc.getStyle(StyleContext.DEFAULT_STYLE);
            Style keywordStyle = sc.addStyle("Keyword", null);
            StyleConstants.setForeground(keywordStyle, new Color(86, 156, 214)); // azul
            Style numberStyle = sc.addStyle("Number", null);
            StyleConstants.setForeground(numberStyle, new Color(181, 206, 168)); // verde claro
            Style stringStyle = sc.addStyle("String", null);
            StyleConstants.setForeground(stringStyle, new Color(206, 145, 120)); // naranja

            doc.setCharacterAttributes(0, doc.getLength(), defaultStyle, true);

            String text = editor.getText();

            for (String kw : KEYWORDS) {
                Pattern p = Pattern.compile("\\b" + kw + "\\b");
                Matcher m = p.matcher(text);
                while (m.find())
                    doc.setCharacterAttributes(m.start(), kw.length(), keywordStyle, true);
            }

            Matcher mn = Pattern.compile("\\b\\d+(\\.\\d+)?\\b").matcher(text);
            while (mn.find())
                doc.setCharacterAttributes(mn.start(), mn.end() - mn.start(), numberStyle, true);

            Matcher ms = Pattern.compile("\"[^\"]*\"").matcher(text);
            while (ms.find())
                doc.setCharacterAttributes(ms.start(), ms.end() - ms.start(), stringStyle, true);
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            IDEV1 ide = new IDEV1();
            ide.setVisible(true);
        });
    }
}

